#include <stdio.h>

void main() {
 printf("Filename : test\n");
 printf("String : banana\n");

 char *word[] = {"banana","apple", "cheery", "grape"};
}

